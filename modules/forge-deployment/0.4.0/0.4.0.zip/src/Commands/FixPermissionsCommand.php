<?php

declare(strict_types=1);

namespace App\Modules\ForgeDeployment\Commands;

use App\Modules\ForgeDeployment\Services\DeploymentStateService;
use App\Modules\ForgeDeployment\Services\SshService;
use Forge\CLI\Attributes\Cli;
use Forge\CLI\Command;
use Forge\CLI\Traits\OutputHelper;

#[Cli(
  command: 'forge-deployment:fix-permissions',
  description: 'Fix file permissions and ownership on the remote server',
  usage: 'forge-deployment:fix-permissions',
  examples: [
    'forge-deployment:fix-permissions',
  ]
)]
final class FixPermissionsCommand extends Command
{
  use OutputHelper;

  public function __construct(
    private readonly DeploymentStateService $stateService,
    private readonly SshService $sshService
  ) {
  }

  public function execute(array $args): int
  {
    $state = $this->stateService->load();

    if ($state === null) {
      $this->error('No deployment state found. Run forge-deployment:deploy first.');
      return 1;
    }

    if ($state->serverIp === null) {
      $this->error('No server IP found in state.');
      return 1;
    }

    $this->info("Fixing permissions on {$state->serverIp}...");

    $sshPrivateKeyPath = $state->sshKeyPath;
    if ($sshPrivateKeyPath && str_starts_with($sshPrivateKeyPath, '~/')) {
      $home = $_SERVER['HOME'] ?? getenv('HOME') ?? '';
      if ($home !== '') {
        $sshPrivateKeyPath = $home . substr($sshPrivateKeyPath, 1);
      }
    }

    $connected = $this->sshService->connect(
      $state->serverIp,
      22,
      'root',
      $sshPrivateKeyPath,
      $sshPrivateKeyPath . '.pub'
    );

    if (!$connected) {
      $this->error("Failed to connect to server: {$state->serverIp}");
      return 1;
    }

    $remotePath = '/var/www/' . $state->domain;

    $this->info("Setting ownership to www-data:www-data...");
    $this->sshService->execute("chown -R www-data:www-data {$remotePath}");

    $this->info("Setting directory permissions to 755...");
    $this->sshService->execute("find {$remotePath} -type d -exec chmod 755 {} \\;");

    $this->info("Setting file permissions to 644...");
    $this->sshService->execute("find {$remotePath} -type f -exec chmod 644 {} \\;");

    $this->info("Setting storage and cache permissions to 775...");
    $this->sshService->execute("chmod -R 775 {$remotePath}/storage");
    $this->sshService->execute("if [ -d {$remotePath}/bootstrap/cache ]; then chmod -R 775 {$remotePath}/bootstrap/cache; fi");

    $this->success("Permissions fixed successfully!");

    return 0;
  }
}
