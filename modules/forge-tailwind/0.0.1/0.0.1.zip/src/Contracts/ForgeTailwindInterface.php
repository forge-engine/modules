<?php

namespace App\Modules\ForgeTailwind\Contracts;

interface ForgeTailwindInterface
{
	public function doSomething(): string;
}