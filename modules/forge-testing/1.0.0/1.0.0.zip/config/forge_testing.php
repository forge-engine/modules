<?php
return [
    "test_directories" => [
        "Tests"
    ],
    "test_suffix" => "Test.php"
];