<?php

namespace Forge\Modules\ForgeTesting\Contracts;

interface ForgeTestingInterface
{
    public function test(): void;
}