<div class="card">
    <h2 class="card--title alert alert--warning">File Not Found</h2>
    <div class="card--body">
        <p>The file you requested at bucket: <span class="font-bold"><?=$bucket ?></span>, path: <span class="font-bold"><?= $path ?></span> could not be found.</p>
    </div>
</div>