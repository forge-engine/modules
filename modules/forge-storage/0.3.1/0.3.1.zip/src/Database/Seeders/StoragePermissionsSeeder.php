<?php

declare(strict_types=1);

use App\Modules\ForgeDatabaseSQL\DB\Seeders\Attributes\AutoRollback;
use App\Modules\ForgeDatabaseSQL\DB\Seeders\Attributes\SeederInfo;
use App\Modules\ForgeDatabaseSQL\DB\Seeders\Seeder;
use App\Modules\ForgeStorage\Enums\Permission;

#[SeederInfo(description: 'Seed storage permissions', author: 'Forge Team')]
#[AutoRollback('permissions', ['name' => 'storage.read'])]
class StoragePermissionsSeeder extends Seeder
{
  public function up(): void
  {
    $permissions = [
      [
        'name' => Permission::StorageRead->value,
        'description' => 'Read access to storage files',
      ],
      [
        'name' => Permission::StorageWrite->value,
        'description' => 'Write/upload access to storage files',
      ],
      [
        'name' => Permission::StorageDelete->value,
        'description' => 'Delete access to storage files',
      ],
      [
        'name' => Permission::StorageList->value,
        'description' => 'List access to storage buckets and files',
      ],
      [
        'name' => Permission::BucketRead->value,
        'description' => 'Read access to bucket contents',
      ],
      [
        'name' => Permission::BucketWrite->value,
        'description' => 'Write access to bucket (create, update)',
      ],
      [
        'name' => Permission::BucketDelete->value,
        'description' => 'Delete access to buckets',
      ],
      [
        'name' => Permission::BucketList->value,
        'description' => 'List access to buckets',
      ],
    ];

    foreach ($permissions as $permission) {
      $stmt = $this->connection->prepare("SELECT COUNT(*) FROM permissions WHERE name = ?");
      $stmt->execute([$permission['name']]);
      $count = (int) $stmt->fetchColumn();

      if ($count === 0) {
        $this->insertBatch('permissions', [
          [
            'name' => $permission['name'],
            'description' => $permission['description'],
            'created_at' => date('Y-m-d H:i:s'),
          ]
        ]);
      }
    }
  }
}
