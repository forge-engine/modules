<?php

declare(strict_types=1);

use App\Modules\ForgeDatabaseSQL\DB\Attributes\GroupMigration;
use App\Modules\ForgeDatabaseSQL\DB\Migrations\Migration;

#[GroupMigration(name: 'storage')]
class EnhanceStorageTable extends Migration
{
  public function up(): void
  {
    $driver = $this->pdo->getDriver();

    $columns = [
      'metadata' => 'TEXT NULL',
      'etag' => 'VARCHAR(64) NULL',
      'version_id' => 'VARCHAR(36) NULL',
    ];

    foreach ($columns as $column => $definition) {
      try {
        if ($driver === 'sqlite') {
          $this->execute("ALTER TABLE storage ADD COLUMN {$column} {$definition}");
        } else {
          $this->execute("ALTER TABLE storage ADD COLUMN {$column} {$definition}");
        }
      } catch (\Exception $e) {
        if (
          !str_contains($e->getMessage(), 'duplicate column') &&
          !str_contains($e->getMessage(), 'already exists')
        ) {
          throw $e;
        }
      }
    }

    try {
      $this->execute("CREATE INDEX idx_storage_etag ON storage(etag)");
    } catch (\Exception $e) {
    }

    try {
      $this->execute("CREATE INDEX idx_storage_created_at ON storage(created_at)");
    } catch (\Exception $e) {
    }
  }

  public function down(): void
  {
    $driver = $this->pdo->getDriver();

    $columns = ['metadata', 'etag', 'version_id'];

    foreach ($columns as $column) {
      try {
        if ($driver === 'sqlite') {
          continue;
        } else {
          $this->execute("ALTER TABLE storage DROP COLUMN {$column}");
        }
      } catch (\Exception $e) {
      }
    }

    try {
      $this->execute("DROP INDEX idx_storage_etag");
    } catch (\Exception $e) {
      // Index might not exist
    }

    try {
      $this->execute("DROP INDEX idx_storage_created_at");
    } catch (\Exception $e) {
      // Index might not exist
    }
  }
}
