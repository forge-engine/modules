<?php

declare(strict_types=1);

use App\Modules\ForgeDatabaseSQL\DB\Attributes\GroupMigration;
use App\Modules\ForgeDatabaseSQL\DB\Migrations\Migration;

#[GroupMigration(name: 'storage')]
class EnhanceBucketsTable extends Migration
{
  public function up(): void
  {
    $driver = $this->pdo->getDriver();

    $columns = [
      'driver' => "VARCHAR(50) DEFAULT 'local'",
      'region' => 'VARCHAR(100) NULL',
      'public_access' => 'BOOLEAN DEFAULT 0',
      'encryption' => 'BOOLEAN DEFAULT 0',
      'versioning' => 'BOOLEAN DEFAULT 0',
    ];

    foreach ($columns as $column => $definition) {
      if ($driver === 'sqlite') {
        try {
          $this->execute("ALTER TABLE buckets ADD COLUMN {$column} {$definition}");
        } catch (\Exception $e) {
          if (!str_contains($e->getMessage(), 'duplicate column')) {
            throw $e;
          }
        }
      } else {
        $this->execute("ALTER TABLE buckets ADD COLUMN {$column} {$definition}");
      }
    }

    try {
      $this->execute("CREATE INDEX idx_buckets_driver ON buckets(driver)");
    } catch (\Exception $e) {
    }
  }

  public function down(): void
  {
    $driver = $this->pdo->getDriver();

    $columns = ['driver', 'region', 'public_access', 'encryption', 'versioning'];

    foreach ($columns as $column) {
      try {
        if ($driver === 'sqlite') {
          continue;
        } else {
          $this->execute("ALTER TABLE buckets DROP COLUMN {$column}");
        }
      } catch (\Exception $e) {
      }
    }

    try {
      $this->execute("DROP INDEX idx_buckets_driver");
    } catch (\Exception $e) {
    }
  }
}
