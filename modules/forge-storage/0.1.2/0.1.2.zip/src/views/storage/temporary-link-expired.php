<div class="card">
    <h2 class="card--title alert alert--warning">Temporary Link Expired</h2>
    <div class="card--body">
        <p>The temporary link you tried to access has expired or is invalid.</p>
    </div>
</div>