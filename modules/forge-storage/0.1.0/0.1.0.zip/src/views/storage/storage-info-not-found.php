<div class="card">
    <h2 class="card--title alert alert--warning">Storage Info Not Found</h2>
    <div class="card--body">
        <p>The requested storage information could not be found.</p>
    </div>
</div>