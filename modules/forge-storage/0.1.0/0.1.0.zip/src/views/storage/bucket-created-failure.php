<div class="card">
    <h2 class="card--title alert alert--error">Error!</h2>
    <div class="card--body">
        <p><?= $error ?></p>
    </div>
</div>