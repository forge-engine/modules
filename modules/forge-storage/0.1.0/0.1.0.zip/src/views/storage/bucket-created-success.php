<div class="card">
    <h2 class="card--title alert alert--success">Success!</h2>
    <div class="card--body">
        <p><?= $message ?></p>
    </div>
</div>