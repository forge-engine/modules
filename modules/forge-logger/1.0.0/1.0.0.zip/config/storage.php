<?php
return [
    "log" => [
        "path" => "storage/logs",
    ],
];
