<?php
return [
    // Default configuration for ForgeTest module
];