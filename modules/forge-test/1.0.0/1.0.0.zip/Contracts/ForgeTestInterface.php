<?php

namespace Forge\Modules\ForgeTest\Contracts;

interface ForgeTestInterface
{
    public function test(): void;
}