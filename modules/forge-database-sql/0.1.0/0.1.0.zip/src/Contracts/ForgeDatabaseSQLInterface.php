<?php

namespace App\Modules\ForgeDatabaseSQL\Contracts;

interface ForgeDatabaseSQLInterface
{
	public function doSomething(): string;
}