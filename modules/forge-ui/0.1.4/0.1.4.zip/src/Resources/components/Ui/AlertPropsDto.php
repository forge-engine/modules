<?php

declare(strict_types=1);

namespace App\Modules\ForgeUi\Resources\Components\Ui;

final class AlertPropsDto
{
    public string $type = '';
    public string $children = '';
}
