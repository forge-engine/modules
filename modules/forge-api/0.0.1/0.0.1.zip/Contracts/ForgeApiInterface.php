<?php

namespace Forge\Modules\ForgeApi\Contracts;

interface ForgeApiInterface
{
    public function test(): void;
}