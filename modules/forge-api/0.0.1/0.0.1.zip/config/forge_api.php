<?php
return [
    // Default configuration for ForgeApi module
];