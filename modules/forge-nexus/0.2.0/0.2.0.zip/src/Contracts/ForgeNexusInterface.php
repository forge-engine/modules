<?php

namespace App\Modules\ForgeNexus\Contracts;

interface ForgeNexusInterface
{
	public function doSomething(): string;
}