<li class="nav-item <?= $isActive ? 'active' : '' ?>">
    <a href="/<?= $target ?>" class="nav-link" rel="prefetch">
        <i class="fa-solid <?= $icon ?>"></i>
        <span><?= $label ?></span>
    </a>
</li>