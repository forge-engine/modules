<div class="sidebar-header">
    <div class="logo-container">
        <div class="logo">
            <i class="fa-solid fa-cube"></i>
        </div>
        <h1 class="app-title"><?= $name ?></h1>
    </div>
</div>