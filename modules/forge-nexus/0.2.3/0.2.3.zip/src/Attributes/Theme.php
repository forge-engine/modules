<?php

declare(strict_types=1);

namespace Modules\FogeNexus\Attributes;

use Attribute;

#[Attribute(Attribute::TARGET_CLASS | Attribute::IS_REPEATABLE)]
final class Theme
{
    public function __construct(
        public string $name,
        public ?string $description = null,
        public ?string $preview = null,
        public ?string $version = "1.0.0",
        public ?string $author = null,
        public ?string $url = null,
        public string $compatibility = '1.0.0',
        public ?string $license = null,
        public string $path,
        public array $ags = []
    ) {
    }
}
