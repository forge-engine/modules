<?php

declare(strict_types=1);

namespace App\Modules\ForgeNexus\Services;

use Forge\Core\DI\Attributes\Service;
use Forge\Core\Module\Attributes\Provides;
use Forge\Core\Module\Attributes\Requires;

#[Service]
#[Provides]
#[Requires]
final class CommandService
{
    public function executeCommand(string $command, ?string $input = null, &$needsInput = false): string
    {
        $forgePath = BASE_PATH . '/forge.php';
        $fullCommand = "php {$forgePath} " . escapeshellcmd($command);
        $descriptorspec = [
            0 => ['pipe', 'r'], // stdin
            1 => ['pipe', 'w'], // stdout
            2 => ['pipe', 'w'], // stderr
        ];
        $process = proc_open($fullCommand, $descriptorspec, $pipes);

        $stdout = '';
        $stderr = '';
        $requiresInput = false;

        if (is_resource($process)) {
            if ($input !== null) {
                fwrite($pipes[0], $input . "\n");
                fclose($pipes[0]);
            }

            // Read output in chunks to detect prompts (very basic)
            while ($output = fgets($pipes[1])) {
                $stdout .= $output;
                if (stripos($output, ':') !== false && !$requiresInput && $input === null) {
                    $requiresInput = true;
                }
            }
            fclose($pipes[1]);

            $stderr = stream_get_contents($pipes[2]);
            fclose($pipes[2]);

            $returnCode = proc_close($process);
        } else {
            return '<span class="color-error">Error executing command.</span>';
        }

        $needsInput = $requiresInput;
        return nl2br(htmlspecialchars($stdout . $stderr));
    }
}
