<?php

namespace App\Modules\ForgeNexus\Contracts;

interface ForgeNexusInterface
{
}
