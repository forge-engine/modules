<?php
layout('main');
?>

<div class="container">
    <h1>Welcome to Nexus CMS Admin</h1>
</div>