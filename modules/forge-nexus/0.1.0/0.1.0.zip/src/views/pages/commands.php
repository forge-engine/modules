<?php
    layout("main");
?>
<div class="container mt-sm">
    <h1 class="mb-sm">Forge Framework Web CLI</h1>

    <div class="card mb-sm">
        <div class="card--body">
            <form method="post" action="/nexus/commands/execute" class="form flex flex--gap-sm">
                <div class="form--group flex-grow">
                    <label for="command" class="form--label sr-only">Enter Command:</label>
                    <input type="text" name="command" id="command" class="form--input" placeholder="Enter Forge command (e.g., help, make:module MyModule)">
                </div>
                <button type="submit" class="button">Execute</button>
            </form>
        </div>
    </div>

    <?php if (isset($command)): ?>
    <div class="card">
        <div class="card--title">Command: <span class="font-bold"><?= htmlspecialchars($command) ?></span></div>
        <div class="card--body">
            <pre class="cli-output"><?= $output ?? '' ?></pre>
            <?php if ($needsInput): ?>
            <form method="post" action="/nexus/commands/send-input" class="form flex flex--gap-sm mt-sm">
                <div class="form--group flex-grow">
                    <label for="input" class="form--label sr-only">Enter Input:</label>
                    <input type="text" name="input" id="input" class="form--input" placeholder="Enter your response">
                </div>
                <button type="submit" class="button button--secondary">Send Input</button>
            </form>
            <?php endif; ?>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
.cli-output {
    background-color: var(--color-neutral-900);
    color: var(--color-neutral-100);
    padding: var(--space-sm);
    border-radius: var(--radius-base);
    font-family: monospace;
    white-space: pre-wrap;
    overflow-y: auto;
    max-height: 500px;
}

.color-error {
    color: var(--color-error);
}
</style>