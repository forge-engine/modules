<?php
use Forge\Core\View\View;

View::layout(name: "nexus", loadFromModule: true);
?>

<div class="container">
    <h1>Welcome to Nexus CMS Admin</h1>
</div>