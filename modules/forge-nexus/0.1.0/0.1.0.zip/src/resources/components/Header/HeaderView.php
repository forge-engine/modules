<header class="content-header">
    <div class="header-left">
        <button class="menu-toggle" aria-label="Toggle sidebar">
            <i class="fa-solid fa-bars"></i>
        </button>
        <h1 class="page-title">Dashboard</h1>
    </div>
    <div class="header-right">
        <button class="action-button" aria-label="Notifications">
            <i class="fa-solid fa-bell"></i>
        </button>
        <button class="action-button" aria-label="Settings">
            <i class="fa-solid fa-gear"></i>
        </button>
    </div>
</header>