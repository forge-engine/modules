<?php

declare(strict_types=1);

namespace App\Modules\ForgeNexus\Controllers;

use App\Modules\ForgeNexus\Services\CommandService;
use Forge\Core\DI\Attributes\Service;
use Forge\Core\Http\Attributes\Middleware;
use Forge\Core\Http\Request;
use Forge\Core\Http\Response;
use Forge\Core\Routing\Route;
use Forge\Traits\ControllerHelper;

#[Service]
#[Middleware('web')]
final class CommandController
{
    use ControllerHelper;

    private ?string $currentCommand = null;

    public function __construct(private CommandService $commandService)
    {
    }

    #[Route("/nexus/commands")]
    public function index(): Response
    {
        return $this->view(view: "pages/commands");
    }

    #[Route("/nexus/commands/execute", "POST")]
    public function execute(Request $request): Response
    {
        $command = $request->postData['command'];
        $this->currentCommand = $command;
        $output = $this->commandService->executeCommand($command, null, $needsInput);

        $data = [
            'command' => $command,
            'output' => $output,
            'needsInput' => $needsInput,
        ];

        return $this->view(view: "pages/commands", data: $data);
    }

    #[Route("/nexus/commands/send-input", "POST")]
    public function sendInput(Request $request): Response
    {
        $input = $request->postData['input'];
        $output = $this->commandService->executeCommand($this->currentCommand, $input);

        $data = [
            'command' => $this->currentCommand,
            'output' => $output,
        ];

        return $this->view(view: "pages/commands", data: $data);
    }
}
