<?php
return [
    'enabled' => true,
    'resources' => [
        'css' => ['css/debugbar.css'],
        'js' => ['js/debugbar.js'],
    ]
];