<?php

declare(strict_types=1);

namespace App\Modules\ForgeHub;

use Forge\Core\DI\Container;
use Forge\Core\Module\Attributes\Compatibility;
use Forge\Core\Module\Attributes\Module;
use Forge\Core\Module\Attributes\Repository;
use App\Modules\ForgeHub\Contracts\ForgeHubInterface;
use App\Modules\ForgeHub\Services\ForgeHubService;
use Forge\Core\DI\Attributes\Service;
use Forge\Core\Module\Attributes\LifecycleHook;
use Forge\Core\Module\LifecycleHookName;
use Forge\CLI\Traits\OutputHelper;
use Forge\Core\Module\Attributes\NexusItem;
use Forge\Core\Module\NexusIcon;
use Forge\Core\Security\PermissionsEnum;

#[Module(name: 'ForgeHub', description: 'Administration Hub for Forge Framework', order: 1)]
#[NexusItem(label: 'CLI Command', route: '/hub/commands', icon: NexusIcon::COG, order: 1, permissions: [PermissionsEnum::RUN_COMMAND, PermissionsEnum::VIEW_COMMAND])]
#[NexusItem(label: 'Logs', route: '/hub/logs', icon: NexusIcon::LOG)]
#[Service]
#[Compatibility(framework: '>=0.1.0', php: '>=8.3')]
#[Repository(type: 'git', url: 'https://github.com/forge-engine/modules')]
final class ForgeHubModule
{
    use OutputHelper;

    public function register(Container $container): void
    {
        $container->bind(ForgeHubInterface::class, ForgeHubService::class);
    }

    #[LifecycleHook(hook: LifecycleHookName::AFTER_MODULE_REGISTER)]
    public function onAfterModuleRegister(): void
    {
    }
}
