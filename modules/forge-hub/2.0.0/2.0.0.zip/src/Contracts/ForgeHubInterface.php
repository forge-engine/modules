<?php

namespace App\Modules\ForgeHub\Contracts;

interface ForgeHubInterface
{
    public function doSomething(): string;
}
