<?php
return [
    'paths' => [],
    'cache' => 'storage/compiled_views',
];
