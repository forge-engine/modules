<?php
return [
    'cache' => 'storage/compiled_views',
];
