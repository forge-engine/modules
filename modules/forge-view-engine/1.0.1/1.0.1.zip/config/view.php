<?php
return [
    'paths' => [
        'views',
        'modules/*/views'
    ],
    'cache' => 'storage/framework/views',
];
