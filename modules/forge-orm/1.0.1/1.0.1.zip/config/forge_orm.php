<?php
return [
    // Default configuration for ForgeOrm module
];