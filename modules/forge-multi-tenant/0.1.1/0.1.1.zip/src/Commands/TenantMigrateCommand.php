<?php
declare(strict_types=1);

namespace App\Modules\ForgeMultiTenant\Commands;

use App\Modules\ForgeMultiTenant\Services\TenantManager;
use App\Modules\ForgeMultiTenant\Services\TenantConnectionFactory;
use Forge\CLI\Command;
use Forge\CLI\Traits\OutputHelper;
use Forge\Core\Database\Migrator;
use Forge\Core\Module\Attributes\CLICommand;
use ReflectionException;
use Throwable;

#[CLICommand(name: 'tenant:migrate', description: 'Run migrations for one or all tenants')]
final class TenantMigrateCommand extends Command
{
    use OutputHelper;

    public function __construct(
        private readonly TenantManager           $manager,
        private readonly TenantConnectionFactory $factory,
        private readonly Migrator $migrator
    ) {}

    /**
     * @throws ReflectionException
     * @throws Throwable
     */
    public function execute(array $args): int
    {
        $tenantId = 'all';
        foreach ($args as $arg) {
            if (str_starts_with($arg, '--tenant=')) {
                $tenantId = substr($arg, 9);
                break;
            }
        }

        foreach ($this->resolveTenants($tenantId) as $tenant) {
            $this->info("Migrating tenant: {$tenant->id}");
            $this->migrator->setConnection($this->factory->forTenant($tenant));
            $this->migrator->run();
        }
        return 0;
    }

    private function resolveTenants(?string $id): array
    {
        return $id === 'all' ? $this->manager->all() : [$this->manager->find($id)];
    }
}