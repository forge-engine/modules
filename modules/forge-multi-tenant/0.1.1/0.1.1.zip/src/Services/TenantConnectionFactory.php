<?php
declare(strict_types=1);

namespace App\Modules\ForgeMultiTenant\Services;

use App\Modules\ForgeMultiTenant\DTO\Tenant;
use App\Modules\ForgeMultiTenant\Enums\Strategy;
use Forge\Core\Database\Connection;
use Forge\Core\Database\DatabaseConfig;
use Forge\Core\DI\Container;
use Forge\Exceptions\MissingServiceException;
use Forge\Exceptions\ResolveParameterException;
use ReflectionException;

final class TenantConnectionFactory
{
    private Container $container;

    public function __construct(Container $container)
    {
        $this->container = $container;
    }

    /**
     * Returns the correct Connection for the current tenant.
     * COLUMN  → same PDO (already cached)
     * VIEW    → same PDO + run SET once
     * DB      → new PDO (cached per tenant)
     */
    public function forTenant(Tenant $tenant): Connection
    {
        $key = 'tenant.conn.' . $tenant->id;

        return $this->container->get($key) ??
            $this->container->singleton($key, fn() => $this->build($tenant));
    }

    /**
     * @throws ResolveParameterException
     * @throws ReflectionException
     * @throws MissingServiceException
     */
    private function build(Tenant $tenant): Connection
    {
        return match ($tenant->strategy) {
            Strategy::COLUMN => $this->container->get(Connection::class),
            Strategy::VIEW   => $this->viewConnection($tenant),
            Strategy::DB     => $this->dbConnection($tenant),
        };
    }

    /**
     * @throws ReflectionException
     * @throws MissingServiceException
     * @throws ResolveParameterException
     */
    private function viewConnection(Tenant $tenant): Connection
    {
        $conn = $this->container->get(Connection::class);
        $conn->exec("SET app.tenant = " . $conn->getPdo()->quote($tenant->id));
        return $conn;
    }

    /**
     * @throws ReflectionException
     * @throws MissingServiceException
     * @throws ResolveParameterException
     */
    private function dbConnection(Tenant $tenant): Connection
    {
        $base = $this->container->get(DatabaseConfig::class);

        $config = new DatabaseConfig(
            driver:   $base->driver,
            database: $tenant->dbName,
            host:     $base->host,
            username: $base->username,
            password: $base->password,
            port:     $base->port,
            charset:  $base->charset
        );
        return new Connection($config);
    }
}