<?php

namespace App\Modules\ForgeMultiTenant\Contracts;

interface ForgeMultiTenantInterface
{
	public function doSomething(): string;
}