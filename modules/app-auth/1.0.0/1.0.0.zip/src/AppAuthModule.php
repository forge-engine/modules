<?php

declare(strict_types=1);

namespace App\Modules\AppAuth;

use App\Modules\ForgeAuth\Services\ForgeAuthService;
use Forge\Core\DI\Container;
use Forge\Core\Module\Attributes\Module;

.0.0',
  description: 'Application-level auth configuration',
  order: 100,
  author: 'Forge Team',
  license: 'MIT',
  type: 'generic',
  tags: ['generic', 'auth', 'authentication', 'authorization', 'authentication-system', 'authentication-library', 'authentication-framework', 'app-auth']
)]
final class AppAuthModule
{
  public function register(Container $container): void
  {
    ForgeAuthService::addCustomClaimsCallback(
      static function ($user): array {
        return [
          'email' => $user->email,
          'identifier' => $user->identifier,
          'tenant_id' => $user->tenant_id ?? null,
        ];
      }
    );
  }
}

