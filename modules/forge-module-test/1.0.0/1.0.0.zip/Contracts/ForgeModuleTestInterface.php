<?php

namespace Forge\Modules\ForgeModuleTest\Contracts;

interface ForgeModuleTestInterface
{
    public function test(): void;
}