<?php
return [
    // Default configuration for ForgeModuleTest module
];