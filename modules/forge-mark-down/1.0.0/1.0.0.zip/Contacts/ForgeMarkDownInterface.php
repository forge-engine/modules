<?php

namespace Forge\Modules\ForgeMarkDown\Contacts;

interface ForgeMarkDownInterface
{
    public function test(): void;
}