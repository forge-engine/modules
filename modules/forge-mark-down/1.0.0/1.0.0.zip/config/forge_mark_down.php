<?php
return [
    // Default configuration for ForgeMarkDown module
];