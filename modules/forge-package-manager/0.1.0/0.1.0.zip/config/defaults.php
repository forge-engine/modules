<?php
return [
	'forge_package_manager' => [
		'registry' => [
		//        [
		//            "name" => "org-modules",
		//            "url" => "https://github.com/acidlake/org-modules",
		//            "branch" => "main",
		//        ],
			],
			'cache_ttl' => 3600 // Cache registry data for 1 hour
	]
];