<?php
return [
    'methods' => [
        'type' => 'array',
        'children' => [
            'get' => [
                'type' => 'string',
                'required' => true,
                'default' => 'GET'
            ]
        ]
    ]
];
