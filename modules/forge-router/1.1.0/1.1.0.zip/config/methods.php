<?php
return [
    'get' => 'GET'
];
