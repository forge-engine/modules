<?php

namespace App\Modules\ForgeComponents\Contracts;

interface ForgeComponentsInterface
{
	public function doSomething(): string;
}