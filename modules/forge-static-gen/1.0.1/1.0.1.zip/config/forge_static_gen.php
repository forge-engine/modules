<?php
return [
    // Default configuration for ForgeStaticGen module
];