<?php
return [
    // Default configuration for ForgeExplicitOrm module
];