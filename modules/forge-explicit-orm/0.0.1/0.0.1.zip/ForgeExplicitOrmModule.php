<?php

namespace Forge\Modules\ForgeExplicitOrm;

use Forge\Core\Contracts\Modules\ModulesInterface;
use Forge\Core\DependencyInjection\Container;

class ForgeExplicitOrmModule extends ModulesInterface
{
    public function register(Container $container): void
    {

    }
}