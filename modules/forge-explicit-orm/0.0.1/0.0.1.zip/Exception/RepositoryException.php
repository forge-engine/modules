<?php

namespace Forge\Modules\ForgeExplicitOrm\Exception;

class RepositoryException extends \Exception
{
    
}