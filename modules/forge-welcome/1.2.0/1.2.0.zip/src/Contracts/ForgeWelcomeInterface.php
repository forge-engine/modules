<?php

namespace App\Modules\ForgeWelcome\Contracts;

interface ForgeWelcomeInterface
{
	public function doSomething(): string;
}