<?php

/**
 * Footer component view.
 * @var array $props
 */
?>
<p class="forge-note">
    Forge - A PHP Kernel for Builders.
</p>