<?php

declare(strict_types=1);

namespace App\Modules\ForgeWelcome\Resources\Components;

use Forge\Core\View\BaseComponent;
use Forge\Core\View\Component;

#[Component(name: "ForgeWelcome:NavBar", useDto: false)]
class NavBar extends BaseComponent
{
    public function render(): string
    {
        return $this->renderview(viewPath: "nav-bar", data: [], loadFromModule: true);
    }
}
