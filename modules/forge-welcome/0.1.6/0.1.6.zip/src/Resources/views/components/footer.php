<?php

/**
 * Footer component view.
 * @var array $props
 */
?>
<p class="forge-note">
    Forge - The PHP Framework Where You Are In Control.
</p>