<?php

declare(strict_types=1);

namespace App\Modules\ForgeWelcome\Resources\Components;

use Forge\Core\View\BaseComponent;
use Forge\Core\View\Component;

#[Component(name: "ForgeWelcome:Footer", useDto: false)]
class Footer extends BaseComponent
{
    public function render(): string
    {
        return $this->renderview(viewPath: "footer", data: [], loadFromModule: true);
    }
}
