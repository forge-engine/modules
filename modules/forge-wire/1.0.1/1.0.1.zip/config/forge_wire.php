<?php

declare(strict_types=1);

return [
    "forge_wire" => [
        "example" => "hi"
    ]
];
