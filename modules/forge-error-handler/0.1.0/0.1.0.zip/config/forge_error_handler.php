<?php

declare(strict_types=1);

return [
    "forge_error_handler" => [
        "example" => "hi"
    ]
];
