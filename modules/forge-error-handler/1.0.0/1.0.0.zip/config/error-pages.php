<?php
return [
    'theme' => 'dark', // or 'light'
    'show_environment' => true,
    'hide_sensitive_data' => [
        'password',
        'api_key'
    ]
];
