<?php

namespace App\Modules\ForgeErrorHandler\Contracts;

interface ForgeErrorHandlerInterface
{
}
