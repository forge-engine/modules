<?php

declare(strict_types=1);

return [
    "forge_events" => [
        "example" => "hi"
    ]
];
